#pragma once
#include <memory>
#include <vector>
#include <map>
#include "VECTOR2.h"

using VEC_INT = std::vector<int>;
#define lpEffect Effect::GetInstance()

struct effectData {
	std::string GHandle;
	VECTOR2 pos;
	int animMaxCnt;
	int timer;
	int animSpeed;
	bool active;
};

class Effect
{
public:
	static Effect &GetInstance()
	{
		static Effect instance;
		return instance;
	}
	void AddEffectList(std::string imgName, VECTOR2 divSize, VECTOR2 divCnt, VECTOR2 chipOffset, int animMaxCnt,int animspeed, VECTOR2 pos);
	void DeleteEffectList(void);
	void EffectDraw(void);
	void SetEffPos(std::string imgName,VECTOR2 pos);
	void SetEffSpeed(std::string imgName, int speed);
	void SetGameFlag(bool flag);
	void WindEffDraw(void);
	bool EffClear(void);
private:
	Effect();
	~Effect();
	struct effectDeleter
	{
		void operator()(Effect* effect) const
		{
			delete effect;
		}
	};
	//std::map<std::string, effectData> effMap;
	std::vector<effectData> effList;
	bool GameMainFlag;
};

