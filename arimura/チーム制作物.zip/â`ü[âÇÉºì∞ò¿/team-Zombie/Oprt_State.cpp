#include "Oprt_State.h"

Oprt_State::~Oprt_State()
{
}
