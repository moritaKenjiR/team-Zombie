<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="マップチップ" tilewidth="32" tileheight="32" tilecount="10" columns="10">
 <image source="../team-Zombie/bitch/color.png" width="320" height="32"/>
 <tile id="0">
  <properties>
   <property name="Collision" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="Collision" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="Collision" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="Collision" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Collision" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Collision" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="Collision" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="Collision" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="Collision" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="Collision" type="bool" value="false"/>
  </properties>
 </tile>
</tileset>
